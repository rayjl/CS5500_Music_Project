/*
 * Enumeration for Format
 * To be used for AudioFile.java
 */
public enum Format {
	WAVE, MP3, MIDI;
}
